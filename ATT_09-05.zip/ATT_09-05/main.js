function entradaDados() {
    const data1 = new Date(document.getElementById('data1').value);
    const data2 = new Date(document.getElementById('data2').value);
    return [data1, data2];
  }

  function maiorData(data1, data2) {
    if (data1 > data2) {
        const maiorData = data1;
        const dia = maiorData.getDate() + 1;
        const mes = maiorData.getMonth() + 1;
        const ano = maiorData.getFullYear();

      return `É a Primeira informada (${dia}/${mes}/${ano})`;
    } else if (data2 > data1){
        const maiorData = data2;
        const dia = maiorData.getDate() + 1;
        const mes = maiorData.getMonth() + 1;
        const ano = maiorData.getFullYear();

      return `É a Segunda informada (${dia}/${mes}/${ano})`;
    } else {
        return `Ambas as datas são iguais`;
    }
  }

  function calcularIntervalo(data1, data2) {
    if (data1 > data2) {
      return "O primeiro parâmetro deve ser mais antigo que o segundo parâmetro.";
    }

    const diffMilissegundos = Math.abs(data2 - data1);
    const diffDias = diffMilissegundos / (1000 * 60 * 60 * 24);
    const diffMeses = diffDias / 30;
    const diffAnos = diffMeses /12;

    return `Diferença das Datas em Dias: ${diffDias}\n
            Diferença das Datas em Meses: ${Math.floor(diffMeses)}\n
            Diferença das Datas em Anos: ${Math.floor(diffAnos)}`;
  }

  function dataAtualFormatada() {
    const dataAtual = new Date();
    const hora = dataAtual.getHours().toString().padStart(2, '0');
    const minuto = dataAtual.getMinutes().toString().padStart(2, '0');
    const dia = dataAtual.getDate().toString().padStart(2, '0');
    const mes = (dataAtual.getMonth() + 1).toString().padStart(2, '0');
    const ano = dataAtual.getFullYear();

    return `Data atual formatada: ${hora}:${minuto} - ${dia}/${mes}/${ano}`;
  }

  function validar() {
    const [data1, data2] = entradaDados();
    const resultadoDiv = document.getElementById('resultado');
    resultadoDiv.innerHTML = `
      <p>Maior data: ${maiorData(data1, data2)}</p>
      <p>${calcularIntervalo(data1, data2)}</p>
      <p>${dataAtualFormatada()}</p>
    `;
  }